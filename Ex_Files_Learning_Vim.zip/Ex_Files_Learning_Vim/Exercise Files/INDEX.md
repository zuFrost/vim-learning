# List of files

- 3.txt
- conway.txt
- day.md
- error.txt
- hello.go
- hello.py
- license-header.txt
- light.txt
- new.txt
- perfect.txt
- persistence.txt
- poppins.txt
- road1.txt
- road2.txt
- sherlock.txt
- sleep.txt
- success.txt
- tebeka.json
- time.txt
- tools.txt
- vimrc-miki.vim
- weather.zip

See more at http://vimdoc.sourceforge.net/htmldoc/usr_toc.html
