# TOC

1. Wake Up
1. Exercise
1. Wash
1. Breakfast & Coffee
1. Reading
1. Work
1. R&R
1. Sleep

## Wake Up

